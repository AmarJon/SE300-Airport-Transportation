package com.example.se300;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

public class ParkingFragment extends Fragment {

    ImageButton informationLogo;
    ImageButton informationLogo2;
    ImageButton informationLogo3;
    ImageButton informationLogo4;
    ImageButton informationLogo5;
    ImageButton informationLogo6;
    ImageButton informationLogo7;
    ImageButton informationLogo8;

    Drawable backgroundInformationLogo;
    Drawable backgroundInformationLogo2;
    Drawable backgroundInformationLogo3;
    Drawable backgroundInformationLogo4;
    Drawable backgroundInformationLogo5;
    Drawable backgroundInformationLogo6;
    Drawable backgroundInformationLogo7;
    Drawable backgroundInformationLogo8;


    View view;

    public ParkingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_parking, container, false);

        informationLogo = view.findViewById(R.id.informationButton);
        informationLogo2 = view.findViewById(R.id.informationButton2);
        informationLogo3 = view.findViewById(R.id.informationButton3);
        informationLogo4 = view.findViewById(R.id.informationButton4);
        informationLogo5 = view.findViewById(R.id.informationButton5);
        informationLogo6 = view.findViewById(R.id.informationButton6);
        informationLogo7 = view.findViewById(R.id.informationButton7);
        informationLogo8 = view.findViewById(R.id.informationButton8);


        backgroundInformationLogo = informationLogo.getBackground();
        backgroundInformationLogo.setAlpha(0);
        backgroundInformationLogo2 = informationLogo2.getBackground();
        backgroundInformationLogo2.setAlpha(0);
        backgroundInformationLogo3 = informationLogo3.getBackground();
        backgroundInformationLogo3.setAlpha(0);
        backgroundInformationLogo4 = informationLogo4.getBackground();
        backgroundInformationLogo4.setAlpha(0);
        backgroundInformationLogo5 = informationLogo5.getBackground();
        backgroundInformationLogo5.setAlpha(0);
        backgroundInformationLogo6 = informationLogo6.getBackground();
        backgroundInformationLogo6.setAlpha(0);
        backgroundInformationLogo7 = informationLogo7.getBackground();
        backgroundInformationLogo7.setAlpha(0);
        backgroundInformationLogo8 = informationLogo8.getBackground();
        backgroundInformationLogo8.setAlpha(0);

        informationLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getActivity(),WebViewActivity.class);
                intent.putExtra("url","https://www.avis.com/en/offers/us-offers/fall-sale?AWD_NUMBER=D486601&gclid=Cj0KCQiAys2MBhDOARIsAFf1D1cyX4AS8MwbrPQM4I5gOb4AN7cfMR_MbpHSUG7w13cHxUHtHjhdpHAaAtACEALw_wcB&gclsrc=aw.ds");
                getActivity().startActivity(intent);
            }
        });



        return view;

    }
}